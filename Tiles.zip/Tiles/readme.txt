Tiles

Contents:
  tiles.py - python tiles code
  tilesdemo.py - tiles demo
  fancytiles.py - code for making different shapes and sizes of tiles
  tiletimes.py - timing code for tiles
  tilesn.py - numarray version of tiles - slower than regular one - not used